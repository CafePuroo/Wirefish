#@Authores: Márcio Moda, João Manoel, Gabriel Pereira, Patrick Matos e Brener Picanço
#
#Arquivo para instalação de pacotes em sh
#
#!/bin/bash

sudo apt update

sudo apt install tshark default-mysql-server default-mysql-client apache -y
